# crumb



This robot model requires:
Ros Indigo, Gazebo 2.X.
Turtlebot packages
arbotix_ros packages



When you execute crumb_world.launch the simulation is paused. 
You can play it directly in Gazebo window.
You can change pause to false and the simulation begins directly but
 the simulator may not load correctly.
 
Don't worry about the warnings error of raysensor, they are because of the pause.
